package za.co.entelect.challenge.enums;

public enum PlayerType {
    A,
    B
}
